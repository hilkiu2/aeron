/*
 * Copyright 2014-2025 Real Logic Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.aeron.samples.cluster.tutorial;

import io.aeron.Aeron;

import io.aeron.cluster.client.AeronCluster;
import io.aeron.cluster.client.ClusterException;
import io.aeron.cluster.client.EgressListener;
import org.agrona.DirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;

import java.nio.charset.StandardCharsets;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicBoolean;

import io.aeron.CommonContext;

import static spark.Spark.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import java.util.HashMap;
import java.util.Map;
import java.net.URLDecoder;
import java.net.InetAddress;
import java.net.UnknownHostException;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static spark.Spark.*;
import com.google.gson.Gson;

import io.aeron.cluster.codecs.EventCode;
import io.aeron.driver.MediaDriver;
import io.aeron.driver.ThreadingMode;
import io.aeron.logbuffer.Header;

import org.agrona.ExpandableArrayBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.BackoffIdleStrategy;
import org.agrona.concurrent.IdleStrategy;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import static io.aeron.samples.cluster.tutorial.BasicKVClusteredService.*;
import static io.aeron.samples.cluster.tutorial.BasicKVClusteredServiceNode.calculatePort;

/**
 * Client for communicating with {@link BasicKVClusteredService}.
 */
// tag::client[]
public class KVHttpServer implements EgressListener
// end::client[]
{
    private AeronCluster aeronCluster;
    private final IdleStrategy idleStrategy = new BackoffIdleStrategy();
    
    private final Map<Long, CompletableFuture<String>> stringResponses = new ConcurrentHashMap<>();
    private final Map<Long, CompletableFuture<Boolean>> boolResponses = new ConcurrentHashMap<>();

    private static final AtomicLong correlationId = new AtomicLong();

    /**
     * Construct a new cluster client for the KV.
     */
    public KVHttpServer() { }

    /**
     * {@inheritDoc}
     */
    // tag::response[]
    public void onMessage(
        final long clusterSessionId,
        final long timestamp,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final Header header)
    {
        final long correlationId = buffer.getLong(offset + CORRELATION_ID_OFFSET);
        final byte status = buffer.getByte(offset + CORRELATION_ID_OFFSET + Long.BYTES);

        System.out.print("OnMessage: { Cluster Session Id: " + clusterSessionId + ", Correlation Id: " + correlationId + ", Status: " + status);

        if (length > Long.BYTES + 1) {
            final CompletableFuture<String> future = stringResponses.remove(correlationId);
            if (future == null) {
                System.out.println(" }");
                System.err.println("No pending GET future found for correlationId: " + correlationId + " }");
                return;
            }

            int valLen = buffer.getInt(offset + CORRELATION_ID_OFFSET + Long.BYTES + 1);
            byte[] valBytes = new byte[valLen];
            buffer.getBytes(offset + CORRELATION_ID_OFFSET + Long.BYTES + 1 + Integer.BYTES, valBytes);
            String value = new String(valBytes, StandardCharsets.UTF_8);
            System.out.println(", Value: " + value + " }");

            future.complete(value);
        } else {
            final CompletableFuture<Boolean> future = boolResponses.remove(correlationId);
            if (future == null) {
                System.err.println("No pending BOOL future found for correlationId: " + correlationId + " }");
                return;
            }

            System.out.println(" }");
            future.complete(status == 1);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void onSessionEvent(
        final long correlationId,
        final long clusterSessionId,
        final long leadershipTermId,
        final int leaderMemberId,
        final EventCode code,
        final String detail)
    {
        System.out.println(
            "onSessionEvent: { Correlation Id: " + correlationId +
            ", Leadership Term Id: " + leadershipTermId + ", Leadership Member Id: " + leaderMemberId +
            ", Code: " + code + ", Detail: " + detail + " }");
    }

    /**
     * {@inheritDoc}
     */
    public void onNewLeader(
        final long clusterSessionId,
        final long leadershipTermId,
        final int leaderMemberId,
        final String ingressEndpoints)
    {
        
        System.out.println(
            "onNewLeader: { Cluster Session Id: " + clusterSessionId +
            ", Leadership Term Id: " + leadershipTermId + ", Leadership Member Id: " + leaderMemberId + "}");
    }
    // end::response[]

    /**
     * Ingress endpoints generated from a list of hostnames.
     *
     * @param hostnames for the cluster members.
     * @return a formatted string of ingress endpoints for connecting to a cluster.
     */
    public static String ingressEndpoints(final List<String> hostnames)
    {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hostnames.size(); i++)
        {
            sb.append(i).append('=');
            sb.append(hostnames.get(i)).append(':').append(
                calculatePort(i, BasicKVClusteredServiceNode.CLIENT_FACING_PORT_OFFSET));
            sb.append(',');
        }

        sb.setLength(sb.length() - 1);

        return sb.toString();
    }

    private void sendPut(final AeronCluster aeronCluster, final String key, final String value, final long corrId)
    {
        final MutableDirectBuffer buffer = new ExpandableArrayBuffer();

        byte[] keyBytes = key.getBytes(StandardCharsets.UTF_8);
        byte[] valBytes = value.getBytes(StandardCharsets.UTF_8);

        int messageLength = HEADER_LENGTH_PUT + keyBytes.length + valBytes.length;

        buffer.putLong(CORRELATION_ID_OFFSET, corrId);
        buffer.putByte(OPCODE_OFFSET, OPCODE_PUT);
        buffer.putInt(KEY_LENGTH_OFFSET, keyBytes.length);
        buffer.putInt(VALUE_LENGTH_OFFSET, valBytes.length);
        buffer.putBytes(HEADER_LENGTH_PUT, keyBytes);
        buffer.putBytes(HEADER_LENGTH_PUT + keyBytes.length, valBytes);

        idleStrategy.reset();
        while (aeronCluster.offer(buffer, 0, messageLength) < 0)
        {
            idleStrategy.idle(aeronCluster.pollEgress());
        }
    }

    private void sendGet(final AeronCluster aeronCluster, final String key, final long corrId)
    {
        final MutableDirectBuffer buffer = new ExpandableArrayBuffer();

        byte[] keyBytes = key.getBytes(StandardCharsets.UTF_8);
        int messageLength = HEADER_LENGTH_GET + keyBytes.length;

        buffer.putLong(CORRELATION_ID_OFFSET, corrId);
        buffer.putByte(OPCODE_OFFSET, OPCODE_GET);
        buffer.putInt(KEY_LENGTH_OFFSET, keyBytes.length);
        buffer.putBytes(HEADER_LENGTH_GET, keyBytes);

        idleStrategy.reset();
        while (aeronCluster.offer(buffer, 0, messageLength) < 0)
        {
            idleStrategy.idle(aeronCluster.pollEgress());
        }
    }

    private void sendCAS(
        final AeronCluster aeronCluster,
        final String key,
        final String expectedValue,
        final String newValue, 
        final long corrId)
    {
        final MutableDirectBuffer buffer = new ExpandableArrayBuffer();

        byte[] keyBytes = key.getBytes(StandardCharsets.UTF_8);
        byte[] expectedBytes = expectedValue.getBytes(StandardCharsets.UTF_8);
        byte[] newBytes = newValue.getBytes(StandardCharsets.UTF_8);

        int messageLength = HEADER_LENGTH_CAS + keyBytes.length + expectedBytes.length + newBytes.length;

        buffer.putLong(CORRELATION_ID_OFFSET, corrId);
        buffer.putByte(OPCODE_OFFSET, OPCODE_CAS);
        buffer.putInt(KEY_LENGTH_OFFSET, keyBytes.length);
        buffer.putInt(EXPECTED_LENGTH_OFFSET, expectedBytes.length);
        buffer.putInt(NEW_LENGTH_OFFSET, newBytes.length);

        int payloadOffset = HEADER_LENGTH_CAS;
        buffer.putBytes(payloadOffset, keyBytes);
        payloadOffset += keyBytes.length;

        buffer.putBytes(payloadOffset, expectedBytes);
        payloadOffset += expectedBytes.length;

        buffer.putBytes(payloadOffset, newBytes);

        idleStrategy.reset();
        while (aeronCluster.offer(buffer, 0, messageLength) < 0)
        {
            idleStrategy.idle(aeronCluster.pollEgress());
        }
    }

    private void sendDelete(final AeronCluster aeronCluster, final String key, final long corrId)
    {
        final MutableDirectBuffer buffer = new ExpandableArrayBuffer();

        byte[] keyBytes = key.getBytes(StandardCharsets.UTF_8);
        int messageLength = HEADER_LENGTH_GET + keyBytes.length;

        buffer.putLong(CORRELATION_ID_OFFSET, corrId);
        buffer.putByte(OPCODE_OFFSET, OPCODE_DELETE);
        buffer.putInt(KEY_LENGTH_OFFSET, keyBytes.length);
        buffer.putBytes(HEADER_LENGTH_GET, keyBytes);

        idleStrategy.reset();
        while (aeronCluster.offer(buffer, 0, messageLength) < 0)
        {
            idleStrategy.idle(aeronCluster.pollEgress());
        }
    }

    public void startHttpServer() {
        port(8081);

        post("/kv/put", (req, res) -> {
            res.type("application/json");

            final String key = req.queryParams("key");
            final String value = req.queryParams("value");

            if (key == null || value == null) {
                res.status(400);
                return "{\"error\": \"Missing 'key' or 'value' parameter\"}";
            }

            final long corrId = correlationId.getAndIncrement();
            final CompletableFuture<Boolean> future = new CompletableFuture<>();
            boolResponses.put(corrId, future);

            sendPut(aeronCluster, key, value, corrId);

            try {
                boolean result = future.get(2, TimeUnit.SECONDS);
                return new Gson().toJson(Map.of("status", "OK", "success", result));
            } catch (TimeoutException e) {
                res.status(504);
                return "{\"error\": \"Timeout waiting for cluster response\"}";
            } catch (Exception e) {
                res.status(500);
                return "{\"error\": \"Unexpected error: " + e.getMessage() + "\"}";
            }
        });

        post("/kv/get", (req, res) -> {
            res.type("application/json");

            final String key = req.queryParams("key");
            if (key == null) {
                res.status(400);
                return "{\"error\": \"Missing 'key' parameter\"}";
            }

            final long corrId = correlationId.getAndIncrement();
            final CompletableFuture<String> future = new CompletableFuture<>();
            stringResponses.put(corrId, future);

            sendGet(aeronCluster, key, corrId);

            try {
                String value = future.get(2, TimeUnit.SECONDS);
                return new Gson().toJson(Map.of("status", "OK", "value", value));
            } catch (TimeoutException e) {
                res.status(504);
                return "{\"error\": \"Timeout waiting for cluster response\"}";
            } catch (Exception e) {
                res.status(500);
                return "{\"error\": \"Unexpected error: " + e.getMessage() + "\"}";
            }
        });

        post("/kv/delete", (req, res) -> {
            res.type("application/json");

            final String key = req.queryParams("key");
            if (key == null) {
                res.status(400);
                return "{\"error\": \"Missing 'key' parameter\"}";
            }

            final long corrId = correlationId.getAndIncrement();
            final CompletableFuture<Boolean> future = new CompletableFuture<>();
            boolResponses.put(corrId, future);

            sendDelete(aeronCluster, key, corrId);

            try {
                Boolean success = future.get(2, TimeUnit.SECONDS);
                return new Gson().toJson(Map.of("status", "OK", "success", success));
            } catch (TimeoutException e) {
                res.status(504);
                return "{\"error\": \"Timeout waiting for cluster response\"}";
            } catch (Exception e) {
                res.status(500);
                return "{\"error\": \"Unexpected error: " + e.getMessage() + "\"}";
            }
        });

        post("/kv/cas", (req, res) -> {
            res.type("application/json");

            final String key = req.queryParams("key");
            final String expected = req.queryParams("expected");
            final String newValue = req.queryParams("new");

            if (key == null || expected == null || newValue == null) {
                res.status(400);
                return "{\"error\": \"Missing 'key', 'expected', or 'new' parameter\"}";
            }

            final long corrId = correlationId.getAndIncrement();
            final CompletableFuture<Boolean> future = new CompletableFuture<>();
            boolResponses.put(corrId, future);

            sendCAS(aeronCluster, key, expected, newValue, corrId); 

            try {
                boolean success = future.get(2, TimeUnit.SECONDS);
                return new Gson().toJson(Map.of("status", "OK", "success", success));
            } catch (TimeoutException e) {
                res.status(504);
                return "{\"error\": \"Timeout waiting for cluster response\"}";
            } catch (Exception e) {
                res.status(500);
                return "{\"error\": \"Unexpected error: " + e.getMessage() + "\"}";
            }
        });
    }

    public void connect(String aeronDir, String ingressEndpoints) {
        try {
            this.aeronCluster = AeronCluster.connect(
                new AeronCluster.Context()
                    .egressListener(this)
                    .egressChannel("aeron:udp?endpoint=localhost:0")
                    .aeronDirectoryName(aeronDir)
                    .ingressChannel("aeron:udp")
                    .ingressEndpoints(ingressEndpoints)
            );

            // Launch keep-alive thread
            new Thread(() -> {
                try {
                    while (true) {
                        aeronCluster.pollEgress();
                        aeronCluster.sendKeepAlive();
                        Thread.sleep(1000);
                    }
                } catch (InterruptedException e) {
                    System.err.println("Keep-alive thread interrupted.");
                }
            }, "Aeron-KeepAlive-Thread").start();

        } catch (Exception e) {
            System.err.println("Failed to connect to Aeron cluster:");
            e.printStackTrace();
        }
    }


    /**
     * Main method for launching the process.
     *
     * @param args passed to the process.
     */
    public static void main(final String[] args)
    {
        System.out.println("Beginning KVHttpServer");
        final String[] hostnames = System.getProperty(
            "aeron.cluster.tutorial.hostnames", "localhost,localhost,localhost").split(",");
        final String ingressEndpoints = ingressEndpoints(Arrays.asList(hostnames));

        System.out.println("Creating client");
        final KVHttpServer client = new KVHttpServer();

       String hostname = "unknown";
        try {
            hostname = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            System.err.println("Failed to resolve local hostname:");
            e.printStackTrace();
        }
        String nodeId = "1";
        if (hostname.matches(".*node(\\d+).*"))
        {
            nodeId = hostname.replaceAll(".*node(\\d+).*", "$1");
        }
        final String aeronDir = CommonContext.getAeronDirectoryName() + "-" + nodeId + "-driver";
        System.out.println("Aeron directory: " + aeronDir);

        // Start HTTP server to control Aeron bidding
        client.connect(aeronDir, ingressEndpoints);
        client.startHttpServer();

        // Keep Aeron running
        System.out.println("HTTP server started");
    }
}
