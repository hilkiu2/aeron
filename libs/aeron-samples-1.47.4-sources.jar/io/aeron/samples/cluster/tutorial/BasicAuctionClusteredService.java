/*
 * Copyright 2014-2025 Real Logic Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.aeron.samples.cluster.tutorial;

import io.aeron.ExclusivePublication;
import io.aeron.Image;
import io.aeron.cluster.codecs.CloseReason;
import io.aeron.cluster.service.ClientSession;
import io.aeron.cluster.service.Cluster;
import io.aeron.cluster.service.ClusteredService;
import io.aeron.logbuffer.FragmentHandler;
import io.aeron.logbuffer.Header;
import org.agrona.*;
import org.agrona.collections.MutableBoolean;
import org.agrona.concurrent.IdleStrategy;

import java.util.Map;
import java.util.HashMap;

import java.util.Objects;

/**
 * Auction service implementing the business logic.
 */
// tag::new_service[]
public class BasicAuctionClusteredService implements ClusteredService
// end::new_service[]
{
    static final int CORRELATION_ID_OFFSET = 0;
    static final int ITEM_ID_OFFSET = CORRELATION_ID_OFFSET + BitUtil.SIZE_OF_LONG;
    static final int PRICE_OFFSET = ITEM_ID_OFFSET + BitUtil.SIZE_OF_LONG;
    static final int BID_MESSAGE_LENGTH = PRICE_OFFSET + BitUtil.SIZE_OF_LONG;
    static final int BID_SUCCEEDED_OFFSET = BID_MESSAGE_LENGTH;
    static final int EGRESS_MESSAGE_LENGTH = BID_SUCCEEDED_OFFSET + BitUtil.SIZE_OF_BYTE;

    private final MutableDirectBuffer egressMessageBuffer = new ExpandableArrayBuffer();
    private final MutableDirectBuffer snapshotBuffer = new ExpandableArrayBuffer();

    // tag::state[]
    private final Auction auction = new Auction();
    // end::state[]
    private Cluster cluster;
    private IdleStrategy idleStrategy;

    /**
     * {@inheritDoc}
     */
    // tag::start[]
    public void onStart(final Cluster cluster, final Image snapshotImage)
    {
        this.cluster = cluster;                      // <1>
        this.idleStrategy = cluster.idleStrategy();  // <2>

        if (null != snapshotImage)                   // <3>
        {
            loadSnapshot(cluster, snapshotImage);
        }
    }
    // end::start[]

    /**
     * {@inheritDoc}
     */
    // tag::message[]
    public void onSessionMessage(
        final ClientSession session,
        final long timestamp,
        final DirectBuffer buffer,
        final int offset,
        final int length,
        final Header header)
    {
        final long correlationId = buffer.getLong(offset + CORRELATION_ID_OFFSET);                   // <1>
        final long itemId = buffer.getLong(offset + ITEM_ID_OFFSET);
        final long price = buffer.getLong(offset + PRICE_OFFSET);

        System.out.printf("[onSessionMessage] Received correlationId=%d for itemId=%d, price=%d%n", correlationId, itemId, price);
        if (price == -1)
        { // This is a read request
            egressMessageBuffer.putLong(CORRELATION_ID_OFFSET, correlationId);
            egressMessageBuffer.putLong(ITEM_ID_OFFSET, itemId);
            egressMessageBuffer.putLong(PRICE_OFFSET, auction.getBestPrice(itemId));
            egressMessageBuffer.putByte(BID_SUCCEEDED_OFFSET, (byte)1); // always success for read

            idleStrategy.reset();
            while (session.offer(egressMessageBuffer, 0, EGRESS_MESSAGE_LENGTH) < 0)
            {
                idleStrategy.idle();
            }
        } else {
            final boolean bidSucceeded = auction.attemptBid(price, itemId);                          // <2>

            if (null != session)                                                                         // <3>
            {
                egressMessageBuffer.putLong(CORRELATION_ID_OFFSET, correlationId);                       // <4>
                egressMessageBuffer.putLong(ITEM_ID_OFFSET, itemId);
                egressMessageBuffer.putLong(PRICE_OFFSET, auction.getBestPrice(itemId));
                egressMessageBuffer.putByte(BID_SUCCEEDED_OFFSET, bidSucceeded ? (byte)1 : (byte)0);

                idleStrategy.reset();
                while (session.offer(egressMessageBuffer, 0, EGRESS_MESSAGE_LENGTH) < 0)                 // <5>
                {
                    idleStrategy.idle();                                                                 // <6>
                }
            } 
        }
    }
    // end::message[]

    /**
     * {@inheritDoc}
     */
    // tag::takeSnapshot[]
    public void onTakeSnapshot(final ExclusivePublication snapshotPublication)
    {
        snapshotBuffer.putInt(0, auction.itemBestPrices.size());
        int snapshotOffset = BitUtil.SIZE_OF_INT;
        for (Map.Entry<Long, Long> entry : auction.itemBestPrices.entrySet())
        {
            snapshotBuffer.putLong(snapshotOffset, entry.getKey());
            snapshotOffset += BitUtil.SIZE_OF_LONG;
            snapshotBuffer.putLong(snapshotOffset, entry.getValue());
            snapshotOffset += BitUtil.SIZE_OF_LONG;
        }

        idleStrategy.reset();
        while (snapshotPublication.offer(snapshotBuffer, 0, snapshotOffset) < 0)            // <2>
        {
            idleStrategy.idle();
        }
    }
    // end::takeSnapshot[]

    // tag::loadSnapshot[]
    private void loadSnapshot(final Cluster cluster, final Image snapshotImage)
    {
        System.out.println("[loadSnapshot]");
        final MutableBoolean isAllDataLoaded = new MutableBoolean(false);
        final FragmentHandler fragmentHandler = (buffer, offset, length, header) ->         // <1>
        {
            System.out.println("[loadSnapshot] Fragment received:");
            System.out.println("    Buffer Length: " + length);
            System.out.println("    Offset: " + offset);

            final int itemCount = buffer.getInt(offset);
            System.out.println("    Item Count: " + itemCount);
            offset += BitUtil.SIZE_OF_INT;
            for (int i = 0; i < itemCount; i++)
            {
                final long itemId = buffer.getLong(offset);
                System.out.println("    Item ID: " + itemId);
                offset += BitUtil.SIZE_OF_LONG;
                final long price = buffer.getLong(offset);
                System.out.println("    Price: " + price);
                offset += BitUtil.SIZE_OF_LONG;
                auction.loadInitialState(itemId, price);
            }

            isAllDataLoaded.set(true);
            System.out.println("[loadSnapshot] Finished parsing fragment.");
        };

        while (!snapshotImage.isEndOfStream())                                              // <4>
        {
            final int fragmentsPolled = snapshotImage.poll(fragmentHandler, 1);

            if (isAllDataLoaded.value)                                                      // <5>
            {
                System.out.println("[loadSnapshot] All data loaded from snapshot fragment.");
                break;
            }

            idleStrategy.idle(fragmentsPolled);                                             // <6>
        }

        System.out.println("[loadSnapshot] Snapshot load complete.");
        assert snapshotImage.isEndOfStream();                                               // <7>
        assert isAllDataLoaded.value;
    }
    // end::loadSnapshot[]

    /**
     * {@inheritDoc}
     */
    public void onRoleChange(final Cluster.Role newRole)
    {
    }

    /**
     * {@inheritDoc}
     */
    public void onTerminate(final Cluster cluster)
    {
    }

    /**
     * {@inheritDoc}
     */
    public void onSessionOpen(final ClientSession session, final long timestamp)
    {
        System.out.println("onSessionOpen(" + session + ")");
    }

    /**
     * {@inheritDoc}
     */
    public void onSessionClose(final ClientSession session, final long timestamp, final CloseReason closeReason)
    {
        System.out.println("onSessionClose(session: " + session + ", reason: " + closeReason + ")");
    }

    /**
     * {@inheritDoc}
     */
    public void onTimerEvent(final long correlationId, final long timestamp)
    {
    }

    static class Auction
    {
        private final Map<Long, Long> itemBestPrices = new HashMap<>();

        void loadInitialState(final long itemId, final long price)
        {
            itemBestPrices.put(itemId, price);
        }

        boolean attemptBid(final long price, final long itemId)
        {
            System.out.println("attemptBid(this=" + this + ", itemId=" + itemId + ", price=" + price + ")");

            final long bestPrice = itemBestPrices.getOrDefault(itemId, 0L);

            if (price <= bestPrice)
            {
                return false;
            }

            itemBestPrices.put(itemId, price);
            return true;
        }

        long getBestPrice(final long itemId)
        {
            return itemBestPrices.getOrDefault(itemId, 0L);
        }

        /**
         * {@inheritDoc}
         */
        public boolean equals(final Object o)
        {
            if (this == o)
            {
                return true;
            }

            if (o == null || getClass() != o.getClass())
            {
                return false;
            }

            final Auction auction = (Auction) o;
            return Objects.equals(itemBestPrices, auction.itemBestPrices);
        }


        /**
         * {@inheritDoc}
         */
        public int hashCode()
        {
            return Objects.hash(itemBestPrices);
        }

        /**
         * {@inheritDoc}
         */
        public String toString()
        {
            return "Auction{" +
                "itemBestPrices=" + itemBestPrices +
                '}';
        }
    }

    /**
     * {@inheritDoc}
     */
    public boolean equals(final Object o)
    {
        if (this == o)
        {
            return true;
        }

        if (o == null || getClass() != o.getClass())
        {
            return false;
        }

        final BasicAuctionClusteredService that = (BasicAuctionClusteredService)o;

        return auction.equals(that.auction);
    }

    /**
     * {@inheritDoc}
     */
    public int hashCode()
    {
        return Objects.hash(auction);
    }

    /**
     * {@inheritDoc}
     */
    public String toString()
    {
        return "BasicAuctionClusteredService{" +
            "auction=" + auction +
            '}';
    }
}
